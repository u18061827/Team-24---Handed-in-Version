﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace The_Food_Works_WebAPI.ViewModels
{
    public class Data
    {
        public class AuthVM
        {
            public string EmailAddress { get; set; }
            public string Password { get; set; }
        }

        public class CustomerVM
        {
            // public int CustomerId { get; set; }
            public string CustomerName { get; set; }
            public string CustomerSurname { get; set; }
            // public DateTime? CustomerDob { get; set; }
            public string CustomerTelephone { get; set; }
            public string CustomerEmail { get; set; }
            // public int IsLoyaltyProgram { get; set; }

            public string Password { get; set; }
        }

        public class ForgotPasswordVM
        {
            [EmailAddress]
            public string Email { get; set; }
        }

        public class ResetPasswordVM
        {
            public string CurrentPassword { get; set; }
            public string email { get; set; }
            public string NewPassword { get; set; }
            public string ConfirmPassword { get; set; }
        }

        public class UserRoleVM
        {
            public int? ID { get; set; }
            public string name { get; set; }
            public string description { get; set; }
        }

        public class OTPvm
        {
            public string email { get; set; }
            public int OTP { get; set; }
        }

        public class ProductVM
        {
            public int ID { get; set; }
            public string name { get; set; }
            public string description { get; set; }
            public int QOH { get; set; }
        }

        public class WriteOffVM
        { 
            public int productId { get; set; }
            public int branchId { get; set; }
            public string WOReason { get; set; }
            public int WOQuantity { get; set; }
        }

        public class SelectedProductVM
        {
            public int SelectedId { get; set; }
            public int BranchId { get; set; }
        }

        public class ReportVM
        {
            public int BranchId { get; set; }
           
            public DateTime endDate { get; set; }
        }
        public class ProductReportVM
        {
            public int BranchId { get; set; }
            public DateTime startDate { get; set; }

            public DateTime endDate { get; set; }
        }
    }

}
