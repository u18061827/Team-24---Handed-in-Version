﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using The_Food_Works_WebAPI.Models;
using The_Food_Works_WebAPI.services;
using static The_Food_Works_WebAPI.ViewModels.Data;

namespace The_Food_Works_WebAPI.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class CustomerController : Controller
    {
        private TheFoodWorksContext db = new TheFoodWorksContext();

        [HttpPost]
        [Route("RegisterCustomer")]
        public ActionResult Register(CustomerVM vm)
        {

            if (this.UserExists(vm.CustomerEmail))
            {
                return Forbid();
            }

            try
            {
                var newCustomer = new Customer
                {
                    // CustomerId = vm.CustomerId,
                    CustomerName = vm.CustomerName,
                    CustomerSurname = vm.CustomerSurname,
                    // CustomerDob = vm.CustomerDob,
                    CustomerTelephone = vm.CustomerTelephone,
                    CustomerEmail = vm.CustomerEmail,
                    // IsLoyaltyProgram = vm.IsLoyaltyProgram,
                };
                db.Customer.Add(newCustomer);
                db.SaveChanges();

                var newUser = new User
                {
                    UserUsername = vm.CustomerEmail,
                    UserPassword = Security.ComputeSha256Hash(vm.Password),

                    UserRoleId = 3,
                    UserStatusId = 1,
                    Customer = newCustomer
                };

                db.User.Add(newUser);
                db.SaveChanges();
                string hashedPassword = newUser.UserPassword;
                var callbackUrl = Url.Action("VerifyEmail", "User", new { key = hashedPassword }, protocol: HttpContext.Request.Scheme);
                new EmailSender().SendEmailAsync(vm.CustomerEmail, "Confirm your account",
                    $"Please confirm your account by clicking this link: <a href='{callbackUrl}'>link</a>");

                return Ok();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        // Helper functions
        private bool UserExists(string EmailAddress)
        {
            var user = db.Customer.Where(zz => zz.CustomerEmail == EmailAddress).FirstOrDefault();

            return user != null;
        }

        private string ComputeSha256Hash(string rawData)
        {
            // Create a SHA256   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

                // Convert byte array to a string   
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

    }
}
