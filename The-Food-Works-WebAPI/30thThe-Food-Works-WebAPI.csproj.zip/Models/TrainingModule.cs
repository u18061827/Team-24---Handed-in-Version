﻿using System;
using System.Collections.Generic;

#nullable disable

namespace The_Food_Works_WebAPI.Models
{
    public partial class TrainingModule
    {
        public TrainingModule()
        {
            EmployeeTrainingModules = new HashSet<EmployeeTrainingModule>();
        }

        public int TrainingModuleId { get; set; }
        public string ModuleName { get; set; }
        public string ModuleDescription { get; set; }
        public string ModuleLanguage { get; set; }
        public string ModuleContentText { get; set; }
        public string ModuleContentVideo { get; set; }
        public byte[] ModuleContentImage { get; set; }
        public TimeSpan ModuleDuration { get; set; }
        public int TrainingModuleTypeId { get; set; }

        public virtual TrainingModuleType TrainingModuleType { get; set; }
        public virtual ICollection<EmployeeTrainingModule> EmployeeTrainingModules { get; set; }
    }
}
