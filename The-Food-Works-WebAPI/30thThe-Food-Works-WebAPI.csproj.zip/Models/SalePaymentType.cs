﻿using System;
using System.Collections.Generic;

#nullable disable

namespace The_Food_Works_WebAPI.Models
{
    public partial class SalePaymentType
    {
        public int PaymentTypeId { get; set; }
        public int SaleId { get; set; }
        public double AmountPaid { get; set; }

        public virtual PaymentType PaymentType { get; set; }
        public virtual Sale Sale { get; set; }
    }
}
